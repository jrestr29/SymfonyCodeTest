<?php

namespace Productos\CalificacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosCalificacionBundle extends Bundle
{
}
