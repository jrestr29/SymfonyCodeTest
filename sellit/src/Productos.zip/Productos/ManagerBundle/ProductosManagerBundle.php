<?php

namespace Productos\ManagerBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosManagerBundle extends Bundle
{
}
