<?php

namespace Productos\ComentariosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosComentariosBundle extends Bundle
{
}
