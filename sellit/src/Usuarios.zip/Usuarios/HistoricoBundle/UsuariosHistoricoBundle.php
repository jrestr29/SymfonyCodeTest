<?php

namespace Usuarios\HistoricoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosHistoricoBundle extends Bundle
{
}
