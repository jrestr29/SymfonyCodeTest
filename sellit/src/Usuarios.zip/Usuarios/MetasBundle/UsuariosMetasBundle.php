<?php

namespace Usuarios\MetasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosMetasBundle extends Bundle
{
}
