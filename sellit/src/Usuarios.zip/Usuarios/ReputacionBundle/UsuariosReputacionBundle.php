<?php

namespace Usuarios\ReputacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosReputacionBundle extends Bundle
{
}
