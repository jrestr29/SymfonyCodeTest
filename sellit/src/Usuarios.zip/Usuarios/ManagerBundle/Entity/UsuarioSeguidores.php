<?php

namespace Usuarios\ManagerBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UsuarioSeguidores
 */
class UsuarioSeguidores
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \Usuarios\ManagerBundle\Entity\Usuarios
     */
    private $idseguido;

    /**
     * @var \Usuarios\ManagerBundle\Entity\Usuarios
     */
    private $idusuario;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set idseguido
     *
     * @param \Usuarios\ManagerBundle\Entity\Usuarios $idseguido
     * @return UsuarioSeguidores
     */
    public function setIdseguido(\Usuarios\ManagerBundle\Entity\Usuarios $idseguido = null)
    {
        $this->idseguido = $idseguido;

        return $this;
    }

    /**
     * Get idseguido
     *
     * @return \Usuarios\ManagerBundle\Entity\Usuarios 
     */
    public function getIdseguido()
    {
        return $this->idseguido;
    }

    /**
     * Set idusuario
     *
     * @param \Usuarios\ManagerBundle\Entity\Usuarios $idusuario
     * @return UsuarioSeguidores
     */
    public function setIdusuario(\Usuarios\ManagerBundle\Entity\Usuarios $idusuario = null)
    {
        $this->idusuario = $idusuario;

        return $this;
    }

    /**
     * Get idusuario
     *
     * @return \Usuarios\ManagerBundle\Entity\Usuarios 
     */
    public function getIdusuario()
    {
        return $this->idusuario;
    }
}
